package com.example.tugas8pmp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
